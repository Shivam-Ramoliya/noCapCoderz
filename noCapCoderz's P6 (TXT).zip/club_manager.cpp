#include <iostream>  // Input/output stream
#include <algorithm> // Standard algorithms library
#include <fstream>   // File stream library
#include <sstream>   // String stream library
#include <cstdlib>   // General utilities library
#include <cstring>   // String manipulation functions
#include <ctime>     // Date and time functions
#include <conio.h>   // Console input/output library
#include <vector>    // Vector container

using namespace std;

// Structure to hold member information
struct Member
{
    int ID;
    char name[20];
    char post[20];
    string club; // Changed to string to hold club name
    long long int Phone_no;
};

// Function prototypes
void main_menu();
void add_new_memb();
void delete_memb();
void search_memb();
void view_memb();
void edit_memb_info();
void return_func();
void Loading();
void add_new_club();
void view_clubs();
void delete_club();
bool sort_clubs(const Member &a, const Member &b); // Function prototype for sorting by club name
string select_club();                              // Function prototype to select club by name

// Main function
int main()
{
    Loading(); // Loading on startup
    return 0;
}

// Main menu function
void main_menu()
{
    system("cls"); // Clear screen
    cout << "============== MAIN MENU ==============" << endl;
    cout << "==\t1. Add Members               ==" << endl;
    cout << "==\t2. Delete Members            ==" << endl;
    cout << "==\t3. Search Members            ==" << endl;
    cout << "==\t4. View Members              ==" << endl;
    cout << "==\t5. Edit Members Information  ==" << endl;
    cout << "==\t6. Add Club                  ==" << endl;
    cout << "==\t7. Delete Club               ==" << endl;
    cout << "==\t8. View Clubs                ==" << endl;
    cout << "==\t9. Close application         ==" << endl;
    cout << "=======================================" << endl;
    cout << "Enter Your Choice: ";
    switch (getch())
    {
    case '1':
        add_new_memb();
        break;
    case '2':
        delete_memb();
        break;
    case '3':
        search_memb();
        break;
    case '4':
        view_memb();
        break;
    case '5':
        edit_memb_info();
        break;
    case '6':
        add_new_club();
        break;
    case '7':
        delete_club();
        break;
    case '8':
        view_clubs();
        break;
    case '9':
        system("cls");
        cout << "\n\n\n======================================================================\n\n\n";
        cout << "\n\n\tTHANK YOU FOR USING DAIIT CLUB Management System\t\n\n";
        cout << "\n\n\n======================================================================\n\n\n";
        exit(0);
    default:
        system("cls"); // Clear screen
        cout << "\a";  // Beep sound for invalid choice
        cout << "Enter Valid Choice !";
        _sleep(500); // Wait for 0.5 sec.
        main_menu();
    }
}

// Function to add a new member
void add_new_memb()
{
    system("cls"); // Clear screen
    Member stu;
    ofstream fout("record_nxt.txt", ios::app); // Open file in append mode
    cout << "Add MEMBER INFO" << endl;
    cout << "Member ID: ";
    cin >> stu.ID;
    cout << "Name: ";
    cin.ignore();
    cin.getline(stu.name, 20);
    cout << "Post: ";
    cin.getline(stu.post, 20);
    stu.club = select_club(); // Select club by name
    cout << "Phone Number: ";
    cin >> stu.Phone_no;
    fout << stu.ID << "\t" << stu.name << "\t" << stu.post << "\t" << stu.club << "\t" << stu.Phone_no << endl; // Write to file
    fout.close();
    cout << "The record is successfully added" << endl;
flag:
    cout << "Add any more (Y/N)? ";
    switch (getch())
    {
    case 'Y':
    case 'y':
    {
        add_new_memb(); // Add another member
        break;
    }
    case 'N':
    case 'n':
    {
        main_menu(); // Add another member
        break;
    }
    default:
    {
        system("cls"); // Clear screen
        cout << "\aEnter Valid Option !" << endl;
        _sleep(500);
        goto flag;
    }
    }
}

// Function to delete a member
void delete_memb()
{
    system("cls");                  // Clear screen
    ifstream fin("record_nxt.txt"); // Open file for reading
    ofstream fout("temp.txt");      // Temporary file for writing
    int d;
    bool found = false;
    Member stu;
    cout << "Enter the Member ID to delete: ";
    cin >> d;
    while (fin >> stu.ID >> stu.name >> stu.post >> stu.club >> stu.Phone_no)
    {
        if (stu.ID != d)
            fout << stu.ID << "\t" << stu.name << "\t" << stu.post << "\t" << stu.club << "\t" << stu.Phone_no << endl; // Write to temporary file
        else
            found = true;
    }
    fin.close();
    fout.close();
    remove("record_nxt.txt");             // Remove original file
    rename("temp.txt", "record_nxt.txt"); // Rename temporary file
    if (found)
        cout << "The record is successfully deleted" << endl;
    else
        cout << "No record found with ID " << d << endl;
    return_func();
}

// Function to search for a member
void search_memb()
{
    while (true)
    {
        system("cls");
        ifstream fin("record_nxt.txt");
        vector<vector<string>> members;
        string line;
        while (getline(fin, line))
        {
            stringstream ss(line);
            vector<string> memberInfo;
            string temp;
            while (getline(ss, temp, '\t'))
            {
                memberInfo.push_back(temp);
            }
            members.push_back(memberInfo);
        }
        fin.close();

        int choice;
        cout << "=====================================" << endl;
        cout << "==\tSearch by:                 ==" << endl;
        cout << "==\t1. Member ID               ==" << endl;
        cout << "==\t2. Member Name             ==" << endl;
        cout << "==\t3. Club Name               ==" << endl;
        cout << "==\t4. Return to MainMenu      ==" << endl;
        cout << "=====================================" << endl;
        cout << "Enter your choice: ";
        switch (getch())
        {
        case '1':
        {
            system("cls"); // Clear screen
            int s;
            bool found = false;
            cout << "Enter the Member ID to search: ";
            cin >> s;
            for (int i = 0; i < members.size(); ++i)
            {
                const auto &member = members[i]; // auto is used to automatically infer the type of the elements.
                if (stoi(member[0]) == s)        // converts a string to its corresponding integer value.
                {
                    cout << "The Member is available" << endl;
                    cout << "ID: " << member[0] << endl;
                    cout << "Name: " << member[1] << endl;
                    cout << "Post: " << member[2] << endl;
                    cout << "Club: " << member[3] << endl;
                    cout << "Phone Number: " << member[4] << endl;
                    found = true;
                    break;
                }
            }
            if (!found)
                cout << "No record found with ID " << s << endl;
            break;
        }
        case '2':
        {
            system("cls"); // Clear screen
            string s;
            bool found = false;
            cout << "Enter the Member Name to search: ";
            cin.ignore();
            getline(cin, s);
            for (int i = 0; i < members.size(); ++i)
            {
                const auto &member = members[i]; // auto is used to automatically infer the type of the elements.
                if (member[1] == s)
                {
                    cout << "The Member is available" << endl;
                    cout << "ID: " << member[0] << endl;
                    cout << "Name: " << member[1] << endl;
                    cout << "Post: " << member[2] << endl;
                    cout << "Club: " << member[3] << endl;
                    cout << "Phone Number: " << member[4] << endl;
                    found = true;
                }
            }
            if (!found)
                cout << "No record found with name " << s << endl;
            break;
        }
        case '3':
        {
            system("cls"); // Clear screen
            string club;
            bool found = false;
            club = select_club(); // Select club by name
            system("cls");
            for (int i = 0; i < members.size(); ++i)
            {
                const auto &member = members[i]; // auto is used to automatically infer the type of the elements.
                if (member[3] == club)
                {
                    cout << "The Member is available" << endl;
                    cout << "ID: " << member[0] << endl;
                    cout << "Name: " << member[1] << endl;
                    cout << "Post: " << member[2] << endl;
                    cout << "Club: " << member[3] << endl;
                    cout << "Phone Number: " << member[4] << endl;
                    cout << endl;
                    found = true;
                }
            }
            if (!found)
                cout << "No record found in club with ID " << club << endl;
            break;
        }
        case '4':
        {
            system("cls");
            main_menu();
            return; // Return to main menu
        }
        default:
        {
            system("cls");
            cout << "\a"; // Beep sound for invalid choice
            cout << "Enter Valid Choice !" << endl;
            _sleep(500); // Wait for 0.5 sec.
            break;
        }
        }
        cout << "Press ENTER to return to the search Member section...";
        getch();
    }
}

// Comparison function to sort members based on club names
bool sort_clubs(const Member &a, const Member &b)
{
    return a.club < b.club;
}

// Function to view all members
void view_memb()
{
    system("cls");                  // Clear screen
    ifstream fin("record_nxt.txt"); // Open file for reading

    vector<Member> members; // Vector to store members

    Member stu;
    while (fin >> stu.ID >> stu.name >> stu.post >> stu.club >> stu.Phone_no)
    {
        members.push_back(stu);
    }
    fin.close();

    // Sort members by club name
    sort(members.begin(), members.end(), sort_clubs);

    // Display sorted members
    cout << "Members List Sorted by Clubs" << endl;
    cout << "<MEM_ID>\t\t<MEMBER NAME>\t\t<Post>\t\t<club>\t\t<PHONE_NO>" << endl;
    for (const auto &member : members)
    {
        cout << "<" << member.club << ">\t\t<" << member.post << ">\t\t<" << member.ID << ">\t\t<" << member.name << ">\t\t<" << member.Phone_no << ">" << endl;
    }

    return_func();
}

// Function to edit member information
void edit_memb_info()
{
    system("cls");                  // Clear screen
    ifstream fin("record_nxt.txt"); // Open file for reading
    ofstream fout("temp.txt");      // Temporary file for writing
    if (!fin || !fout)
    {
        cerr << "Error: Unable to open files for editing." << endl;
        return;
    }
    int s;
    bool found = false;
    Member stu;
    cout << "Edit MEMBER info" << endl;
    cout << "Enter the Member ID to edit: ";
    cin >> s;
    while (fin >> stu.ID >> stu.name >> stu.post >> stu.club >> stu.Phone_no)
    {
        if (stu.ID == s)
        {
            cout << "The Member is available" << endl;
            cout << "Name: ";
            cin.ignore();
            cin.getline(stu.name, sizeof(stu.name));
            cout << "Post: ";
            cin.getline(stu.post, sizeof(stu.post));
            stu.club = select_club(); // Select club by name
            cout << "Phone Number: ";
            cin >> stu.Phone_no;
            found = true;
        }
        fout << stu.ID << "\t" << stu.name << "\t" << stu.post << "\t" << stu.club << "\t" << stu.Phone_no << endl;
    }
    fin.close();
    fout.close();
    remove("record_nxt.txt");
    rename("temp.txt", "record_nxt.txt");
    if (!found)
    {
        cout << "No record found with ID " << s << endl;
    }
    else
    {
        cout << "Member information updated successfully" << endl;
    }
    return_func();
}

// Function to return to main menu
void return_func()
{
    cout << "Press ENTER to return to the main menu...";
    getch();
    main_menu();
}

// Function for Loading page
void Loading()
{
    system("cls"); // Clear screen
    char ch;
    cout << endl;
    cout << "========= DAIICT CLUB MANAGEMENT SYSTEM =========" << endl;
    cout << endl;
    cout << "Press ENTER to use Our System.....";
    getch();
    system("cls"); // Clear screen
    cout << endl;
    cout << "========= DAIICT CLUB MANAGEMENT SYSTEM =========" << endl;
    cout << endl;
    cout << "\n\t\tPlease Wait!!" << endl;
    cout << "\t\tLoading ";
    for (int i = 0; i <= 6; i++)
    {
        cout << ".";
        _sleep(500); // Wait for 0.2 seconds
    }
    system("cls");
    main_menu(); // Go to main menu
}

// Function to add club
void add_new_club()
{
    system("cls");
    ofstream fout("clubs.txt", ios::app);
    char clubName[20];
    cout << "Enter Club Name: ";
    cin.getline(clubName, 20);
    fout << clubName << endl;
    fout.close();
    cout << "Club added successfully!" << endl;
    cout << "Add any more (Y/N)? ";
    if (getch() == 'n' || getch() == 'N')
        main_menu(); // Return to main menu
    else
        add_new_club(); // Add another club
}

// Function to select club by name
string select_club()
{
    ifstream fin("clubs.txt");
    vector<string> clubs;
    string clubName;
    int club = 1;

    cout << "Select Club:" << endl;
    cout << "----------------" << endl;

    while (getline(fin, clubName))
    {
        clubs.push_back(clubName);
        cout << club << ". " << clubName << endl;
        club++;
    }

    fin.close();

    cout << "----------------" << endl;

    int choice;
    cout << "Enter Club ID: ";
    cin >> choice;

    if (choice < 1 || choice > clubs.size())
    {
        cout << "Invalid Club ID" << endl;
        _sleep(500);
        main_menu();
    }

    return clubs[choice - 1];
}

// Function to View all the Clubs.
void view_clubs()
{
    system("cls");             // Clear screen
    ifstream fin("clubs.txt"); // Open file for reading
    string club;
    int i = 1;
    cout << "Members List" << endl;
    cout << "<CLUBS>" << endl;
    while (fin >> club)
    {
        cout << "<" << i << "." << club << ">" << endl;
        i++;
    }
    fin.close();
    return_func();
}

// Function to delete club
void delete_club()
{
    system("cls");             // Clear Screen
    ifstream fin("clubs.txt"); // Open file for reading
    ofstream fout("temp.txt"); // Open file for writing

    vector<string> clubs;
    string clubName;
    int clubID = 1;
    cout << "Select Club to Delete:" << endl;
    cout << "----------------" << endl;
    while (getline(fin, clubName))
    {
        clubs.push_back(clubName);
        cout << clubID << ". " << clubName << endl;
        clubID++;
    }
    fin.close();

    cout << "----------------" << endl;
    int choice;
    cout << "Enter Club ID to Delete: ";
    cin >> choice;
    if (choice < 1 || choice > clubs.size())
    {
        cout << "Invalid Club ID!" << endl;
        _sleep(500);
        delete_club();
    }
    cout << "Deleting club: " << clubs[choice - 1] << endl;
    clubs.erase(clubs.begin() + choice - 1);
    fout.close();

    ofstream fout2("clubs.txt");
    for (const string &club : clubs)
    {
        fout2 << club << endl;
    }
    fout2.close();
    cout << "Club deleted successfully!" << endl;
    return_func();
}
